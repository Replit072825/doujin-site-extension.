Doujin Site Launcher (Chrome Extension)

Cara pasang di Chrome desktop:
1. Ekstrak file ZIP ini.
2. Buka chrome://extensions
3. Aktifkan Developer mode.
4. Klik Load unpacked.
5. Pilih folder hasil ekstrak "doujin_site_extension".

Klik ikon extension lalu pilih "Buka Website".

Catatan:
- Extension ini hanya shortcut/launcher ke https://doujin.desu.xxx/.
- Extension tidak mengubah atau menyimpan konten situs.
- Chrome Android resmi tidak mendukung pemasangan extension dari folder seperti Chrome desktop. Pada Android, gunakan browser yang mendukung extension (jika tersedia) atau buka situs langsung.
